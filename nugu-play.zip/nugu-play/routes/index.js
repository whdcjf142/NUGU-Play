const express = require('express');
const nugu = require('../nugu');
const router = express.Router();

router.post(`/nugu/Action.brokenteeth`, nugu);
router.post(`/nugu/Action.burn`, nugu);
router.post(`/nugu/Action.nosebleed`, nugu);
router.post(`/nugu/Action.scratch`, nugu);
router.post(`/nugu/Action.eyesensation`, nugu);
router.post(`/nugu/Action.convulsion`, nugu);
router.post(`/nugu/Action.beesting`, nugu);
router.post(`/nugu/Action.abrasion`, nugu);
router.post(`/nugu/Action.bruise`, nugu);
router.post(`/nugu/Action.sprain`, nugu);
router.post(`/nugu/Action.earbug`, nugu);
router.post(`/nugu/Action.pimple`, nugu);
router.post(`/nugu/Action.stomachache`, nugu);
router.post(`/nugu/Action.mosquito`, nugu);
router.post(`/nugu/Action.dryeye`, nugu);


module.exports = router;