module.exports = {
  SERVER_PORT: process.env.SERVER_PORT || 3000
}
