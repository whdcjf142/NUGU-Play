/*var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : '172.22.201.205:3306',
  user     : 'root',
  password : 'asasas12',
  database : 'ng'
});
  
connection.connect();
  
connection.query('SELECT * FROM 응급조치', function (error, results, fields) {
    if (error) {
        console.log(error);
    }
    console.log(results);
});
  
connection.end();
*/